"""中证1000股指期权独立配置。"""

from .config_schema import (
    AppConfig,
    BacktestConfig,
    DataConfig,
    ReferenceCurveConfig,
    ReportConfig,
    StrategyConfig,
    VolConfig,
)

CONFIG = AppConfig(
    data=DataConfig(
        product="zz1000",
        etf_dir="data/zz1000/index",
        opt_dir="data/zz1000/option",
        hedge_etf_dir="data/zz1000/hedge_etf",
    ),
    backtest=BacktestConfig(
        # 当前 AKShare 本地连续样本为 2022-08-01 到 2025-12-31。
        start="20220801",
        end="20260101",
        test_date="20220801",
        initial_cash=1_000_000,
        min_cash_reserve=50_000,
        # 中证1000股指期权
        long_qty=1,
        short_qty=1,
        etf_fee_rate=0.00005,
        option_fee_per_contract=2.0,
        liquidity_warning_volume_ratio=0.005,
    ),
    strategy=StrategyConfig(
        enable_long_straddle=True,
        enable_short_straddle=True,
        long_open_iv_threshold=0.14,
        long_close_iv_threshold=0.23,
        min_exit_dte=3,
        short_signal_mode="absolute",
        short_open_iv_threshold=0.2,
        short_close_iv_threshold=0.16,
        short_open_iv_percentile_threshold=0.75,
        short_close_iv_percentile_threshold=0.60,
        short_stop_loss_enabled=True,
        short_stop_loss_rate=0.2,
        enable_delta_hedge=False,
        short_volume_spike_exit_enabled=True,
        short_volume_spike_multiplier=1.5,
        short_cooldown_after_long_iv_high_exit_days=3,
        roll_dte_threshold=7,
        roll_strike_mismatch_days=2,
        roll_cooldown_days=1,
    ),
    vol=VolConfig(
        annual_days=252,
        hv_windows=(60,),
        atm_iv_percentile_window=252,
        atm_target_dte=20,
        atm_target_dte_min=7,
        atm_target_dte_max=30,
        # 中证1000行权价档位是指数点位，ATM 偏离容忍度不能沿用 50ETF 的 0.10 元。
        atm_moneyness_tol=100,
        # 中证1000股指期权合约乘数为每点 100 元。
        contract_multiplier=100,
        risk_free_rate=0.0,
        dividend_yield=0.0,
    ),
    report=ReportConfig(
        output_root="output",
        daily_feature_cols=("yz_hv60", "atm_iv_percentile"),
    ),
    reference=ReferenceCurveConfig(
        # 中证1000配置先只验证主策略，参考曲线之后单独调参。
        enable_always_atm=False,
        always_atm_side="short",
        always_atm_qty=25,
        always_atm_enable_delta_hedge=False,
        enable_experiment=False,
        experiment_short_signal_mode="absolute",
        experiment_enable_delta_hedge=False,
        experiment_enable_long_straddle=True,
        experiment_enable_short_straddle=True,
        experiment_short_stop_loss_enabled=False,
        experiment_short_volume_spike_exit_enabled=True,
        experiment_short_cooldown_after_long_iv_high_exit_days=3,
        experiment_long_qty=None,
        experiment_short_qty=None,
    ),
)
